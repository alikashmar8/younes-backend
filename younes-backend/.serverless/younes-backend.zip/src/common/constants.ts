
export const BCRYPT_SALT = 10;
export const JWT_SECRET = 'younes_secret';
export const JWT_EXPIRES_IN = '1h';
export const JWT_REFRESH_EXPIRES_IN = '1d';
export const JWT_REFRESH_SECRET = 'younes_refresh_secret';
export const JWT_REFRESH_COOKIE_NAME = 'younes_refresh_token';
export const JWT_COOKIE_NAME = 'younes_token';
export const JWT_REFRESH_COOKIE_EXPIRES_IN = '1d';
export const JWT_REFRESH_COOKIE_SECRET = 'younes_refresh_secret';
export const JWT_REFRESH_COOKIE_DOMAIN = 'localhost';
export const JWT_REFRESH_COOKIE_PATH = '/';
export const JWT_REFRESH_COOKIE_HTTP_ONLY = false;
export const BUSINESS_LOGO_PATH = 'uploads/businesses-logos/';
export const GALLERY_FILES_IMAGES_PATH = 'uploads/gallery-items/';
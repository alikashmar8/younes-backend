export enum GalleryItemType {
  FILE = 'file',
  FOLDER = 'folder',
}
